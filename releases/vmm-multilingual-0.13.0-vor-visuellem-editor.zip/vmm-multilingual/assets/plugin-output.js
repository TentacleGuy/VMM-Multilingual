/* Only plugin-owned shortcode roots, never form values or the surrounding page. */
(()=>{
    const config=window.vmmPluginOutput;if(!config)return;
    const excluded='script,style,textarea,pre,code,svg,noscript,[contenteditable]';
    document.querySelectorAll('.vmm-plugin-output').forEach(root=>{
        const plugin=root.dataset.plugin,context=root.dataset.context,map=config.translations[plugin]||{},seen=new Set();let timer;
        const rows=[];
        const value=(source,tag,attr='')=>{
            const key=context+' · '+tag+(attr?' · '+attr:'');
            if(map[key]&&Object.hasOwn(map[key],source))return map[key][source];
            if(config.capture&&source.trim()&&source.length<=4000&&/\p{L}/u.test(source)){
                const id=JSON.stringify([tag,attr,source]);if(!seen.has(id)&&seen.size<500){seen.add(id);rows.push({tag,attr,source});}
            }return source;
        };
        const scan=()=>{
            observer.disconnect();
            const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let node;
            while(node=walker.nextNode()){
                const parent=node.parentElement;if(!parent||parent.closest(excluded)||parent.closest('.vmm-plugin-output')!==root)continue;
                const source=node.nodeValue,result=value(source,parent.tagName.toLowerCase());if(result!==source)node.nodeValue=result;
            }
            root.querySelectorAll('*').forEach(el=>{
                if(el.closest(excluded)||el.closest('.vmm-plugin-output')!==root)return;
                for(const attr of ['placeholder','aria-label','title','alt','src','href']){
                    if(!el.hasAttribute(attr)||(attr==='src'&&el.tagName!=='IMG'))continue;
                    const source=el.getAttribute(attr);if(/^(javascript:|data:|#)/i.test(source))continue;
                    const result=value(source,el.tagName.toLowerCase(),attr);if(source!==result)el.setAttribute(attr,result);
                }
            });
            observer.observe(root,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['placeholder','aria-label','title','alt','src','href']});
            if(config.capture&&rows.length){
                const batch=rows.splice(0,100),body=new URLSearchParams({action:'vmm_output_capture',nonce:config.nonce,plugin,context,rows:JSON.stringify(batch)});
                fetch(config.ajax,{method:'POST',credentials:'same-origin',body}).catch(()=>{});
                if(rows.length)timer=setTimeout(scan,400);
            }
        };
        const observer=new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(scan,400);});scan();
    });
})();
